#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_CLIENTS	5
#define BUFLEN 256


void error(char *msg)
{
    perror(msg);
    exit(1);
}


		// Structura in care imi definesc clientul
typedef struct{
	char nume[12];
	char prenume[12];
	long numar_card;
	int pin;
	char parola_secreta[16];
	double sold;
}client;


char * mesaj;


int main(int argc, char *argv[])
{	
// variabile si contoare declarate	
	double suma_de_depus;
	char* mesaj_trimitere;
	long nr_card, number_clients, blocked_card;
	int pin_card, i, dec, log_corect = 0, suma_de_retras = 0;
	char first_line[10], line[70], *comanda, mesaj[70];
	int client_existent, incercari_pin = 0, ses_deschisa = 0;

	// deschid fisierul de citire clienti
	FILE* f = fopen(argv[2], "r");	
	fgets(first_line, 10, f);
	number_clients = atol(first_line);
	// Copii datele clientilor din fisier intr-un vector de structura
	client  vec_of_clients[number_clients];
	for(i = 0; i < number_clients; i++){
		fscanf(f, "%s%s%ld%d%s%lf", vec_of_clients[i].nume, vec_of_clients[i].prenume, &vec_of_clients[i].numar_card, &vec_of_clients[i].pin, vec_of_clients[i].parola_secreta, &vec_of_clients[i].sold);
	}

     int sockfd, newsockfd, portno, clilen;
     char buffer[BUFLEN];
     struct sockaddr_in serv_addr, cli_addr;
     int n, j;

     fd_set read_fds;	//multimea de citire folosita in select()
     fd_set tmp_fds;	//multime folosita temporar 
     int fdmax;		//valoare maxima file descriptor din multimea read_fds

     if (argc < 2) {
         fprintf(stderr,"Usage : %s port\n", argv[0]);
         exit(1);
     }

     //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);
     
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");

     portno = atoi(argv[1]);

     memset((char *) &serv_addr, 0, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
     serv_addr.sin_port = htons(portno);
     
     if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) 
              error("ERROR on binding");
     
     listen(sockfd, MAX_CLIENTS);
	 int optval = 1;
     setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(int));
     //adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
     FD_SET(sockfd, &read_fds);
     fclose(f);

    fdmax = sockfd;
	char* aux;
	int to_fd;

     // main loop
	while (1) {
		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");
	
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
			
				if (i == sockfd) {
					// a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
					// actiunea serverului: accept()
					clilen = sizeof(cli_addr);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) == -1) {
						error("ERROR in accept");
					} 
					else {
						//adaug noul socket intors de accept() la multimea descriptorilor de citire
						FD_SET(newsockfd, &read_fds);
						if (newsockfd > fdmax) { 
							fdmax = newsockfd;
						}
					}
					printf("Noua conexiune de la %s, port %d, socket_client %d\n ", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), newsockfd);
				}
					
				else {
					// am primit date pe unul din socketii cu care vorbesc cu clientii
					//actiunea serverului: recv()
					memset(buffer, 0, BUFLEN);
					if ((n = recv(i, buffer, sizeof(buffer), 0)) <= 0) {
						if (n == 0) {
							//conexiunea s-a inchis
							printf("selectserver: socket %d hung up\n", i);
						} else {
							error("ERROR in recv");
						}
						close(i); 
						FD_CLR(i, &read_fds); // scoatem din multimea de citire socketul pe care 
					} 
					else { //recv intoarce >0
						// Functia de login
						// citesc comanda primita
						comanda = strtok(buffer," ");
						if(strcmp(comanda, "login") == 0){
							comanda = strtok(NULL, " "); 
							nr_card = atol(comanda);
							client_existent = 0;	// contor pentru client existent
							if(ses_deschisa == 1){		// verific daca clietul nu este logat deja
								sprintf(buffer,"ATM>-2 : Sesiune deja deschisa\n");
								send(i, buffer, sizeof(buffer), 0);
							}
							else{
								int ceva = 0;		// parcurg clientii din vectorul de structura cu clienti
								for(j = 0; j < number_clients; j++){
									// verific daca numarul de card primit este corect
									if(vec_of_clients[j].numar_card == nr_card){
										ceva = 1;	// contor pentru numar card gresit
										comanda = strtok(NULL, " ");		// extrag pinul primit in buffer de la client
										pin_card = atoi(comanda);
										// verific daca pinul este corect si daca nu a fost introdus de mai mult de 3 ori
										if(pin_card == vec_of_clients[j].pin && incercari_pin < 3){
											// trimit mesajul la client
											sprintf(buffer, "ATM> Wellcome %s %s\n", vec_of_clients[j].nume, vec_of_clients[j].prenume);
											send(i, buffer, sizeof(buffer), 0);
											// actualizez contoarele
											incercari_pin = 1;
											log_corect = 1;
											ses_deschisa = 1;
										}
										// daca sa tastat de 3 ori pinul greisit blokez cardul
										else if(incercari_pin == 2){
											sprintf(buffer, "ATM> -5 : Card blocat\n");
											send(i, buffer, sizeof(buffer), 0);
										}
										// daca sa introdus pinul gresit de mai putin de 3 ori trimit mesaj la client
										else if(incercari_pin < 2){
											sprintf(buffer,"ATM> -3 : Pin gresit\n");
											send(i, buffer, sizeof(buffer), 0);
											incercari_pin++;
											blocked_card = vec_of_clients[j].numar_card;
										}
									}
								} // daca sa tastat gresit numarul cardului 
								if(ceva == 0){
									sprintf(buffer, "ATM> -4 : Numar card inexistent\n");
									send(i, buffer, sizeof(buffer), 0);

								}
                    		}
                    	} 
                    	// Functia de logout
                    	if(strcmp(buffer, "logout\n") == 0){
                    		if(log_corect == 0){		// daca nu sa realizat loginul
                    			sprintf(buffer, "-1 : Clientul nu este autentificat\n");
                    			send(i, buffer, sizeof(buffer), 0);
                    		}
                    		else{
                    			// daca clientul este logat, il deloghe trimit mesaj la client si actualizaez counterii
                    			log_corect = 0;
                    			incercari_pin = 1;
                    			client_existent = 0;
                    			ses_deschisa = 0;
                    			sprintf(buffer, "ATM> Deconectare de la bancomat\n");
                    			send(i, buffer, sizeof(buffer), 0);
                    		}

                    	}
                    	// Functia de listsold
                    	char comm[8];
                    	memcpy(comm, buffer, 8);
                    	comm[8] = '\0';		// extrag functia apelata din payloadul bufferului
                    	if(strcmp(comm, "listsold") == 0){
                    		// verific daca nu clietul e logat
                    		if(log_corect == 0){
                    			sprintf(buffer, "-1 : Clientul nu este autentificat\n");
                    			send(i, buffer, sizeof(buffer), 0);
                    		}
                    		else{
                    			// daca clientul e logat extrax numarul_cardului clientului pentru a putea indentifica
                    			char aux[10];
                    			sscanf(buffer, "listsold\n%s", aux);
                    			// fac conversi din string in long pentru nr cardului
                    			nr_card = atol(aux);
                    			// iterez prin lista de clientzi si verific daca am gasit clientul cu nr de card respectiv
                    			for(j = 0;  j < number_clients; j++){
                    				if(nr_card == vec_of_clients[j].numar_card){
                    					// trimit mesaj de afisare sold catre client
                    					sprintf(buffer, "ATM> %.2lf\n", vec_of_clients[j].sold);
                    					send(i, buffer, sizeof(buffer), 0);
                    				}
                    			}
                    		}
                    	}

                    	// Functia de getmoney(retragere bani)
                    	char prefix[8];
                    	memcpy(prefix, buffer, 8);
                    	prefix[8] = '\0';		// extrag comanda din buffer 
                    	if(strcmp(prefix, "getmoney") == 0){
                    		// verific daca exista client logat
                    		if(log_corect == 0){
                    			sprintf(buffer, "-1 : Clientul nu este autentificat\n");
                    			send(i, buffer, sizeof(buffer), 0);
                    		}
                    		// daca da atunci extrag suma si nr de card
                    		else{
                    			char aux[10];
                    			char suma_char[10];
                    			printf("%s\n", buffer);
                    			sscanf(buffer, "getmoney %d\n.%ld",&suma_de_retras, &nr_card);
                    			// verific ca suma sa fie multiplu de 10
                    			if(suma_de_retras % 10 == 0){
                    				// iterez prin clienti
                    				for(j = 0;  j < number_clients; j++){
                    					// verific numarul cardului
                    					if(nr_card == vec_of_clients[j].numar_card){
                    						// verific ca suma de extragere sa fie mai mica decat soldul curent
                    						if(vec_of_clients[j].sold > suma_de_retras){
                    							// actualizez soldul clientului si trimit mesajul de afisare catre client
                    							vec_of_clients[j].sold = vec_of_clients[j].sold - suma_de_retras;
                    							sprintf(buffer, "ATM> Suma %d retrasa cu succes\n", suma_de_retras);
                    							send(i, buffer, sizeof(buffer), 0);
                    						}
                    						// daca suma de extras e mai mare ca soldul trimit mesajul
                    						else{
                    							sprintf(buffer, "ATM> -8 : Fonduri insuficiente");
                    							send(i, buffer, sizeof(buffer), 0);
                    						}
                    					}
                    				}
                    			} // daca suma nu e multiplu de 10 trimit mesajul
                    			else{
                    				sprintf(buffer, "ATM> -9 : Suma nu este multiplu de 10");
                    				send(i, buffer, sizeof(buffer), 0);
                    			}
                    		}
                    	}

                    	// Functia de putmoney(pune bani in cont)
                    	char pref[8];
                    	memcpy(pref, buffer, 8);
                    	pref[8] = '\0';		// extrag comanda de 8 caractere primita in buffer de la client
                    	if(strcmp(pref, "putmoney") == 0){
                    		// verific daca clientul e logat
                    		if(log_corect == 0){
                    			sprintf(buffer, "-1 : Clientul nu este autentificat\n");
                    			send(i, buffer, sizeof(buffer), 0);
                    		}
                    		// daca e logat
                    		else{
                    			char aux[10];
                    			char suma_char[10];
                    			// extrag suma si nr cardului
                    			sscanf(buffer,"putmoney %lf\n.%ld",&suma_de_depus, &nr_card);
                    			for(j = 0;  j < number_clients; j++){
                    				// itez prin lista de clienti si caut clientul cu nr cardului primit
                    				if(nr_card == vec_of_clients[j].numar_card){
                    					// actualizez soldul si trimit mesajul catre client
                    					vec_of_clients[j].sold = vec_of_clients[j].sold + suma_de_depus;
                    					sprintf(buffer, "ATM> Suma depusa cu succes\n");
                    					send(i, buffer, sizeof(buffer), 0);
                    				}
                    			}
                    		}
                    	}
                    	// Functia de quit 
                    	if(strcmp(buffer, "quit\n") == 0){
                    		close(sockfd);		// daca e quit inchid sochetul clientului si ies
                    		return 0;
                    	}
					}
				} 
			}
		}
    }
    close(sockfd);
   
    return 0; 
}
