#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <arpa/inet.h>

#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    char numefisier[20] = "client-";
    char processID[10];
    sprintf(processID, "%d", getpid());
    strcat(numefisier, processID);
    strcat(numefisier, ".log"); // creare nume fisier de scriere mesaje
    FILE *f = fopen(numefisier, "a");       // deschidere fisier
    int sockfd, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    fd_set read_fds;    //multimea de citire folosita in select()
    fd_set tmp_fds; //multime folosita temporar
    int fdmax;      //valoare maxima file descriptor din multimea read_fds

    char buffer[BUFLEN];
    if (argc < 3) {
       fprintf(stderr,"Usage %s server_address server_port\n", argv[0]);
       exit(0);
    }  
    
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &serv_addr.sin_addr);
    
    
    if (connect(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");    
    
    FD_SET(0, &read_fds);
    FD_SET(sockfd, &read_fds);
    fdmax = sockfd + 1;

    memset(buffer, 0, sizeof(buffer));
    int variabila = 0;
    long numar_card_client;
    long numar_logat;
    // bucla TCP client de trimitere primire
  		while(1){
        tmp_fds = read_fds;
        if (select(fdmax, &tmp_fds, NULL, NULL, NULL) == -1)
            error("ERROR in select");

        if (FD_ISSET(0, &tmp_fds)) {
            memset(buffer, 0, sizeof(buffer));
            // citire de la tastatura in buffer
            fgets(buffer, BUFLEN-1, stdin);
            char comanda[16];
            // creare sir de tip comanda pentru a indentifica comanda dupa primele 5 caractere
            memset(comanda, 0, sizeof(comanda));
            memcpy(comanda, buffer, 5);
            // verific daca comanda citita e login
            if(strcmp(comanda, "login") == 0){
                int xe;
                sscanf(buffer, "login %ld %d\n", &numar_card_client, &xe);
                // verific daca exista o sesine deschisa deja
                if(variabila == 1){
                    printf("-2 : Sesiune deja deschisa\n");
                }
                else{
                //trimit mesaj la server
                    n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0)
                    error("ERROR writing to socket");
                }
            }
            // verific daca comanda e logout
            if(strcmp(comanda, "logou") == 0){
                variabila = 0;      // reactulizez contorul
                // trimit mesajul la server
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0)
                    error("ERROR writing to socket");
            }
            // verific daca comanda e listsold 
            if(strcmp(comanda, "lists") == 0){
                char vec[10];
                sprintf(vec, "%ld", numar_logat);
                strcat(buffer, vec);        // concatenez comanda cu numarul de card al clientului
                //trimit la server
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0)
                    error("ERROR writing to socket");
            }
            // verific daca comanda e getmoney
            if(strcmp(comanda, "getmo") == 0){
                char vec[10];
                sprintf(vec, "%ld", numar_logat);
                strcat(buffer, ".");
                strcat(buffer, vec);        // concatenez comanda cu numarul cardului cl si trimit la server
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0)
                    error("ERROR writing to socket");
            }// verific daca comanda e putmoney
            if(strcmp(comanda, "putmo") == 0){
                char vec[10];
                sprintf(vec, "%ld", numar_logat);
                strcat(buffer, ".");
                strcat(buffer, vec);        // concatenez comanda cu numarul cardului cl si trimit la server
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0)
                    error("ERROR writing to socket");
            }
            // verfic daca e quit
            if(strcmp(comanda, "quit\n") == 0){
                n = send(sockfd,buffer,strlen(buffer), 0); //trimit la server 
                if (n < 0)
                    error("ERROR writing to socket");
                fclose(f); // inchidere fisier de scriere
            }
        }
        if (FD_ISSET(sockfd, &tmp_fds)) {
            n = recv(sockfd, buffer, sizeof(buffer),0);
            char mesaj[9];
            memset(mesaj, 0, 9);
            memcpy(mesaj, buffer, 9);
            if(strcmp(mesaj, "ATM> Well") == 0){
                variabila = 1;      // actualizez variabila de logare
                numar_logat = numar_card_client;        // retin numarul cardului
            }
            if(strcmp(mesaj, "ATM> Deco") == 0){
                variabila = 0;      // actualizez contorul
            }
            if (n == 0) {
                error("Connection was closed!");
                break;
            }
            if (n < 0)
                error("ERROR reading from socket");

            printf("%s\n", buffer); // afisare buffer
            fprintf(f,"%s", buffer);
            memset(buffer, 0, sizeof(buffer));
        }

    }
    
    return 0;
}




