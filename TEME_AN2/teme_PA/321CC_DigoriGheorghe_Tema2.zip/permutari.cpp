/*
* Copyright (C) 2017, Digori Gheorghe
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include <list>
using namespace std;
#define pb push_back

ifstream f("permutari.in");		// deschid fisierul de input
ofstream out("permutari.out");		// deschid fisierul de output
int alfabet = 26;


int min(int x, int y) {
	if (x > y)
    	return x;
	else
    	return y;
}


class graph {
	public:
	int numar_noduri;
	// instantiez lista de adiacenta
	list<int> *lista_adj = new list<int>[numar_noduri];
	explicit graph(int nr) : numar_noduri(nr) { }

	// functie auxiliara ce marcheaza nodul curent ca vizitat si apeleaza
	// in mod recursiv functia pentru nodurile adiacente
	void functie_recursiva(vector<int> &rezultat, bool vizitat[], int i) {
	    list<int>::iterator it;
		vizitat[i] = true;
		// iterez prin lista de adiacenta
		for(it = lista_adj[i].begin(); it != lista_adj[i].end(); ++it) {
			if(vizitat[*it] != true) {
				functie_recursiva(rezultat, vizitat, *it);
			}
		}
		// aduaga nodul curent in vectorul rezultat
		rezultat.pb(i);
	}

	// functie auxiliara
	bool check_cycle_aux(bool visit[], bool rec_visit[], int v) {
		if(visit[v] == false) {
			visit[v] = true;
			rec_visit[v] = true;
			list<int>::iterator i;
        	for(i = lista_adj[v].begin(); i != lista_adj[v].end(); i++) {
           		if ( !visit[*i] && check_cycle_aux(visit, rec_visit, *i) )
                	return true;
            	else if (rec_visit[*i])
                	return true;
        	}
		}
		rec_visit[v] = false;
		return false;
	}

	// functie ce verifica existenta unui ciclu intr-un graf
	bool check_cycle() {
		bool *vizitat = new bool[numar_noduri];
    	bool *vizitat2 = new bool[numar_noduri];
    	for(int i = 0; i < numar_noduri; i++) {
        	vizitat[i] = false;
        	vizitat2[i] = false;
    	}
    	for(int i = 0; i < numar_noduri; i++)
        	if (check_cycle_aux(vizitat, vizitat2, i))
            	return true;
    	return false;
	}

	// functie ce foloseste functie_recursiva
	void sortareTopologica() {
		vector<int> rezultat;
		int i = 0, j = 0;
	    bool *vizitat = new bool[alfabet];
	    // se marcheaza toate nodurile ca fiind nevizitate
	    while (i < numar_noduri) {
	        vizitat[i] = false;
	        i++;
	    }

	    while (j < numar_noduri) {
	        if (vizitat[j] == false)
	            functie_recursiva(rezultat, vizitat, j);
	        j++;
	    }
	    // verifica ca toate conditiile sa fie indeplinite in acelasi timp
	    if (check_cycle()) {
			out << "Imposibil";
			return;
		}
		// altfel afiseaza stringul rezultat
		while (rezultat.empty() != true) {
			out << (char) ('a' + rezultat.back());
			rezultat.pop_back();
		}
	}
};



int main() {
	int N, i = 0, j = 0;
	f >> N;		// citire din fisier numar de cuvinte
	string h;
	graph G(alfabet); 	// graf ce contine 26 de noduri
	vector<string> cuvinte;
	for (i = 0; i < N; i++) {
		f >> h;
		cuvinte.push_back(h);
	}
	// parcurg fiecare cuvant citit
	for(i = 0; i < N-1; i++) {
		// stochez primele cuvinte
		string cuv1 = cuvinte[i];
		string cuv2 = cuvinte[i+1];
		// gasesc cuvantul ce are dimensinea mai mica
		int minimum = min(cuv1.length(), cuv2.length());
		for(j = 0; j < minimum; j++) {
			// verific daca sunt caractere diferite
			if(cuv1[j] != cuv2[j]) {
				// adaug muchia in lista de adiacenta a grafului G
				G.lista_adj[cuv1[j]-'a'].pb(cuv2[j]-'a');
				break;
			}
		}
	}
	// Afisez rezultatul ordinii topologice a grafului creat
	G.sortareTopologica();
	return 0;
}
