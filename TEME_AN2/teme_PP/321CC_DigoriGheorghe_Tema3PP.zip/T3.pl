% TODO: <Digori> <Gheorghe> <321CC>

:- ensure_loaded('T3t.pl').
:- ensure_loaded('T3base.pl').
:- dynamic next_tile/2.


% initial_game_state(-GameState).
% Întoarce în GameState starea inițială a jocului.
initial_game_state(S) :- S = [[((1, 1), '#0', 0), ((2, 1), '#0', 0), ((3, 1), '#0', 0), ((4, 1), '#0', 0), ((5, 1), '#0', 0), ((6, 1), '#0', 0), ((7, 1), '#0', 0), ((8, 1), '#0', 0)],
                              [((1, 2), '#0', 0), ((2, 2), '#0', 0), ((3, 2), '#0', 0), ((4, 2), '#0', 0), ((5, 2), '#0', 0), ((6, 2), '#0', 0), ((7, 2), '#0', 0), ((8, 2), '#0', 0)],
                              [((1, 3), '#0', 0), ((2, 3), '#0', 0), ((3, 3), '#0', 0), ((4, 3), '#0', 0), ((5, 3), '#0', 0), ((6, 3), '#0', 0), ((7, 3), '#0', 0), ((8, 3), '#0', 0)],
                              [((1, 4), '#0', 0), ((2, 4), '#0', 0), ((3, 4), '#0', 0), ((4, 4), '#0', 0), ((5, 4), '#0', 0), ((6, 4), '#0', 0), ((7, 4), '#0', 0), ((8, 4), '#0', 0)],
                              [((1, 5), '#0', 0), ((2, 5), '#0', 0), ((3, 5), '#0', 0), ((4, 5), '#0', 0), ((5, 5), '#0', 0), ((6, 5), '#0', 0), ((7, 5), '#0', 0), ((8, 5), '#0', 0)],
                              [((1, 6), '#0', 0), ((2, 6), '#0', 0), ((3, 6), '#0', 0), ((4, 6), '#0', 0), ((5, 6), '#0', 0), ((6, 6), '#0', 0), ((7, 6), '#0', 0), ((8, 6), '#0', 0)],
                              [((1, 7), '#0', 0), ((2, 7), '#0', 0), ((3, 7), '#0', 0), ((4, 7), '#0', 0), ((5, 7), '#0', 0), ((6, 7), '#0', 0), ((7, 7), '#0', 0), ((8, 7), '#0', 0)],
                              [((1, 8), '#0', 0), ((2, 8), '#0', 0), ((3, 7), '#0', 0), ((4, 8), '#0', 0), ((5, 8), '#0', 0), ((6, 8), '#0', 0), ((7, 8), '#0', 0), ((8, 8), '#0', 0)]].



% get_game_tiles(+GameState, -PlacedTileList)
% Întoarce lista de cărți rotite plasate în joc.
% Lista este o listă de triplete conținând:
% - coordonatele (X, Y) ale spațiului unde este cartea
% - identificatorul cărții (#1..#10)
% - identificatorul rotației (R0..R3)


%Itereaza prin lista primita si returneaza intro lista de iesire elementele cu ID diferit "#0".
diff_zero([],[]).
diff_zero([(_,B,_)|T],[(_,B,_)|S]) :-
    B \= '#0',
    diff_zero(T, S).
diff_zero([_|T], S) :-
    diff_zero(T, S).
get_game_tiles(X,Y) :- append(X,Z), diff_zero(Z,Y).



% merge la urmatoare celula In matrice in functie de directie
next_cell(X, Y, NextX, NextY, s) :-
  NextX is X,
  NextY is Y+1.

next_cell(X, Y, NextX, NextY, n) :-
  NextX is X,
  NextY is Y-1.

next_cell(X, Y, NextX, NextY, e) :-
  NextX is X+1,
  NextY is Y.

next_cell(X, Y, NextX, NextY, w) :-
  NextX is X-1,
  NextY is Y.

% itereaza printr-o lista de elemente pornnind de la elementul 1
iterator([X|_], X, 1).
iterator([_|T], X, N) :-
  N \= 1,
  NewN is N - 1,
  iterator(T, X, NewN).

% itereza printr-o lista pornind de la elemetul 0
iterator_by0([X|_], X, 0).
iterator_by0([_|T], X, N) :-
    N \= 0,
    NewN is N - 1,
    iterator_by0(T, X, NewN).
% gaseste o celula intr-o matrice la coordonatele (X,Y) si o returneaza in C
find_cell(B, X, Y, C) :-
  iterator(B, Linia, Y),
  iterator(Linia, C, X).
% roteste elementele unei liste circulare la dreapta sau la stanga
rotleft([E|T], R) :-
     append(T,[E],R).

rotright(L, R) :-
     rotleft(R, L).

% returneaza in D directia(n sau w sau e sau s) ex:?-trim_list([s,e,n,w,s,e,n,w], e, D, 2)
trim_list([X|T], D_in, D_out, Delta) :-
  X = D_in,
  iterator_by0([X|T], D_out, Delta).

trim_list([X|T], D_in, D_out, Delta) :-
  X \= D_in,
  trim_list(T, D_in, D_out, Delta).

% returneaza lista de conexiuni a unei carti in functie de ID
tolist(Id, List) :-
  tile(X, Y, Z, Q, Id),
  List = [X, Y, Z, Q].

% roteste o lista circulara de conexiuni cu n pozitii la dreapta
n_rotate_tile(L, 0, L).
n_rotate_tile(L, N, R) :-
  N \= 0,
  rotright(L, Q),
  NewN is N -1,
  n_rotate_tile(Q, NewN, R).

% returneaza in X directia
get_direction([X,_,_,_],w, X).
get_direction([_,Y,_,_],s, Y).
get_direction([_,_,Z,_],e, Z).
get_direction([_,_,_,W],n, W).

%verifica daca 2 ID primite ca argumente sunt diferite
id_diff_0(Id,F) :-
  Id \= F.
% gaseste delta(directia) pentru o carte ex: ?-resolve_dir(n, '#7', 'R1', X).
resolve_dir(D_in, Id, Rotation, D_out) :-
  rotation(NRot,Rotation),
  tolist(Id, List),
  n_rotate_tile(List, NRot, L_out),
  get_direction(L_out, D_in, Delta),
  trim_list([s,e,n,w,s,e,n,w], D_in, D_out, Delta).

%predicat ce inllocuiete directia, folosit la trecerea dntr-o celula in alta
%exemplu:astfel daca se iese prin s din celula 1 se intra prin nord
mirror(s, n).
mirror(n, s).
mirror(w, e).
mirror(e, w).

%rotatiile posibile pentru o carte.
rotatii_carti(Id, ['R0'])
  :- Id = '#1' ;
     Id = '#6' ;
     Id = '#9' ;
     Id = '#10'.
rotatii_carti(Id, ['R0', 'R1'])
   :- Id = '#4' ;
      Id = '#8'.
rotatii_carti(Id, ['R0', 'R1', 'R2', 'R3'])
   :- Id = '#2';
      Id = '#3';
      Id = '#5';
      Id = '#7'.

%gasesc urmatoarea celula in functie de celula curenta si directie
next_cell_in_path(Stare, In, ((X, Y), Id, Rotation), Celula) :-
  id_diff_0(Id, '#0'),
  width(W),
  between(1, W, X),
  height(H),
  between(1, H, Y),
  resolve_dir(In, Id, Rotation, Out_rezul),
  next_cell(X, Y, NewX, NewY, Out_rezul),
  find_cell(Stare, NewX, NewY, Celula).


%gasesc toate celulele de pe granita care sunt goale dintr-o stare primita si le pun intr-o lista.
first_zero_cells(Stare, List_fist_cells) :-
  height(H),
  findall( (L, NextX, NextY),
    (entry_point(X, Y, D),
    next_cell(X, Y, NextX, NextY, D),
    (NextX, NextY) \= (1, 1),
    (NextX, NextY) \= (H, H),
    (NextX, NextY) \= (1, H),
    (NextX, NextY) \= (H, 1),
    find_cell(Stare, NextX, NextY, C),
    C = (_, '#0', _),
    mirror(D, In),
    L = [In]),
    Lst),
  List_fist_cells = [([n, w], 1, 1), ([e, s], H, H), ([w, s], 1, H), ([n, e], H, 1) | Lst].






% get_open_paths(+GameSteate, -Paths)
% Întoarce în Paths o listă de trasee care pornesc
% dintr-un punct de intrare și nu ajung într-un punct
% de ieșire. Elementele din fiecare traseu vor fi citite
% folosind predicatele get_path_*

%returneaza o lista pentru cazul de baza
get_open_paths(_,B) :- B =[].

% get_closed_paths(+GameState, -ClosedPaths)
% Întoarce în ClosedPaths traseele care pornesc
% dintr-un punct de intrare și ajung într-un punct
% de ieșire. Elementele din fiecare traseu vor fi citite
% folosind predicatele get_path_*
%returnez o lista pentru cazul de baza
get_closed_paths(_,F) :- F = [].


% get_path_entry(+Path, -Point)
% Întoarce în Point o pereche (X, Y) care este punctul
% de intrare pentru un traseu. Pentru X și Y întoarse
% trebuie ca entry_point(X, Y, _) să fie adevărat.
get_path_entry(_,L) :- L = [].

% get_path_tiles(+Path, -IDs)
% Întoarce în IDs o listă de perechi (TID, RID)
% care conține, în ordinea în care sunt parcurse de traseu,
% pentru fiecare carte parcursă identificatorul cărții și
% identificatorul rotației acesteia.
% Este posibil ca o carte să apară în traseu de mai multe ori,
% dacă traseul trece de mai multe ori prin ea.

%returneaza o lista pentru cazul de baza
get_path_tiles(_, Z) :- Z = [].



% available_move(+GameState, -Move)
% Predicatul leagă argumentul Move la o mutare disponibilă
% în starea GameState a jocului. Formatul pentru Move trebuie
% să fie același ca și în cazul utilizării predicatelor
% get_move_*.
% Dacă Move este legat, predicatul întoarce true dacă mutarea
% este disponibilă.
% Dacă Move nu este legat, soluții succesive (obținute folosind
% comanda ; la consolă, sau obținute cu findall) vor oferi
% diverse mutări valide în starea de joc dată.
% findall(Move, available_move(State, Move), Moves) trebuie să
% întoarcă în Moves toate mutările valide în starea dată, fără
% duplicate.

%prdicate logice
and(L,R) :- L,R.
and(A,B,C,D) :- A,B,C,D.
or(L,R, F, M) :- L;R;F;M.
nand(A,B,C,D) :- not(and(A,B,C,D)).
xor(A,B,C,D) :- or(A,B,C,D), nand(A,B,C,D).

%verifica daca 2 id-uri sunt diferite
check_id(Id,F) :-
  Id == F.

%verific daca celula primita e la margine.
check_celule_vecine(_, ID, X, Y) :-
  width(W),
  height(H),
  or(X = 1, Y = 1, X = W, Y = H),
  check_id(ID, '#0').

%verific daca mutarea primita se poate aplica si daca da
%verifica daca in jurul mutarii respective pe directia n, s,w,e exista vrio carte
%de care sa o pot lega.
%returneaza true sau false.
check_celule_vecine(A, ID, X, Y) :-
  width(W),
  height(H),
  and(X > 1, Y > 1, X < W, Y < H),
  next_cell(X, Y, X_e, Y_e, e),
  next_cell(X, Y, X_s, Y_s, s),
  next_cell(X, Y, X_w, Y_w, w),
  next_cell(X, Y, X_n, Y_n, n),
  find_cell(A, X_e, Y_e, C_e),
  find_cell(A, X_s, Y_s, C_s),
  find_cell(A, X_w, Y_w, C_w),
  find_cell(A, X_n, Y_n, C_n),
  get_TID(C_e, ID_e),
  get_TID(C_s, ID_s),
  get_TID(C_w, ID_w),
  get_TID(C_n, ID_n),
  and(check_id(ID, '#0'),
    (\+check_id(ID_e, '#0');\+check_id(ID_s, '#0');\+check_id(ID_w, '#0');\+check_id(ID_n, '#0'))).


%predicat ce primeste o stare si genereaza mutari valide care indeplinesc conditiile.
get_available_move(Stare, ((X, Y), ID, Rotation))
          :- first_zero_cells(Stare, List_celule_marginale), %gasesc lista de celule marginale
             member(Q, List_celule_marginale),
             Q = (In_directions, X, Y),
             tile(_, _, _, _, ID), %iau toate ID -urile cartilor
             rotatii_carti(ID, List_of_rotation), %gasesc rotatiile valide pentru carte cu ID primit
             member(Rotation, List_of_rotation),
             findall(Out_rezult,
              (member(In, In_directions),
              resolve_dir(In, ID, Rotation, Out_rezult),
              next_cell(X, Y, NextX, NextY, Out_rezult),
              exit_point(NextX, NextY, _)), %gaseste toate celulele care au path =1
              List_rezult),
             List_rezult = [].


%functie ce determina mutarile valide ale unei stari.
available_move(A,((X,Y),ID, Rot)) :- get_available_move(A, ((X,Y),ID, Rot)).
% Atenție! Folosirea celor 3 predicate get_move_* pe aceeași
% variabilă neinstanțiată Move trebuie să rezulte în legarea
% lui Move la o descriere completă a mutării, astfel încât
% available_move(FS, Move) să dea adevărat dacă mutarea
% descrisă este validă în starea GS a jocului.

% get_move_space(?Move, ?Space)
% Predicatul este adevărat dacă Space corespunde spațiului
% (X, Y) de pe hartă unde a fost pusă o carte în urma
% mutării Move.
% Vezi și observația de mai sus.

%retuneaza coordonatele uneii celule
get_XY(((X,Y),_,_), (A, B)) :-
       A = X,
       B = Y.
get_move_space(M,S) :- get_XY(M,S).

% get_move_tile_id(?Move, ?TID)
% Predicatul este adevărat dacă TID corespunde
% identificatorului ('#1'..'#10') cărții care a fost plasată
% pe hartă în urma mutării Move.
% Vezi și observația de mai sus.

%retuneaza ID-ul uneii celule
get_TID((_,X,_), A) :-
       A = X.
get_move_tile_id(M,S) :- get_TID(M,S).

% get_move_rotation_id(?Move, ?RotID)
% Predicatul este adevărat dacă RotID corespunde
% identificatorului rotației ('R0'..'R3') cărții care a fost
% plasată în urma mutării Move.
% Vezi și observația de mai sus.

%retuneaza Rotatia uneii celule
get_RotID((_,_,X), A) :-
       A = X.
get_move_rotation_id(M,R) :- get_RotID(M, R).



% apply_move(+GameStateBefore, +Move, -GameStateAfter)
% Leagă al treilea argument la starea de joc care rezultă
% în urma aplicării mutării Move în starea GameStateBefore.


%aplica o mutare pe tabla primita
apply_move(_,_,_) :- fail.

% pick_move(+GameState, +TID, -Move)
% Alege o mutare care folosește cartea cu identificatorul TID,
% pentru a fi aplicată în starea GameState. Mutarea este
% întoarsă în Move.
pick_move(_,_,_) :- fail.


% play_game(-FinalGameState)
% Joacă un joc complet, pornind de la starea inițială a jocului
% și continuând până când nu se mai poate pune cartea care
% este la rând.
% Cărțile de plasat se obțin folosind
% predicatul next_tile(+Time, -TID), unde Time este legat la
% numărul de mutări realizate până în momentul curent, iar
% predicatul next_tile va lega TID la un identificator de carte.
play_game(_) :- fail.
