/*
* Copyright (C) 2017, Digori Gheorghe
*/
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
#define vec vector<char>


ifstream f("adn.in");		// deschidere fisier input
ofstream g("adn.out");		// deschidere fisier output


int X[111][111][111][111];		// Matrice de 4 dimensiuni

		// functie auxiliara ce verfica caracterele din vectorii substringurilor
int verificare(vec A, vec v1, vec v2, vec v3, vec v4) {
		// calculez lungimile substringurilor
    int l1 = v1.size();
    int l2 = v2.size();
    int l3 = v3.size();
    int l4 = v4.size();
    int l = A.size();		// lungimea stringului A
    if (l1 + l2 + l3 + l4 != l) {
        return 0;			// daca suma lungimilor substringuriloe e diferita
    }						// termin executia
    // parcurgere vectorii de substringuri
    for (int i = 0; i <= l1; i++) {
        for (int j = 0; j <= l2; j++) {
            for (int x = 0; x <= l3; x++) {
                for (int y = 0; y <= l4; y++) {
                    X[i][j][x][y] = 0;		// Matrice de dimensiune 4 initializata
                    if (i == 0 && j == 0 && x == 0 && y == 0) {
                        X[i][j][x][y] = 1;		// daca toti vectorii sunt 0
                    } else {
                        int index = i + j + x + y - 1;
                        char t = A[index];		// target
                        // verific fiecare caracteer din substringul 1
                        int ii = i - 1;
                        if (ii >= 0 && v1[ii] == t && X[ii][j][x][y] == 1) {
                            X[i][j][x][y] = 1;
                            continue;
                        }
                        // verific fiecare caracteer din substringul 2
                        int jj = j - 1;
                        if (jj >= 0 && v2[jj] == t && X[i][jj][x][y] == 1) {
                            X[i][j][x][y] = 1;
                            continue;
                        }
                        // verific fiecare caracteer din substringul 3
                        int xx = x - 1;
                        if (xx >= 0 && v3[xx] == t && X[i][j][xx][y] == 1) {
                            X[i][j][x][y] = 1;
                            continue;
                        }
                        // verific fiecare caracteer din substringul 4
                        int yy = y - 1;
                        if (yy >= 0 && v4[yy] == t && X[i][j][x][yy] == 1) {
                            X[i][j][x][y] = 1;
                            continue;
                        }
                    }
                }
            }
        }
    }
    return X[l1][l2][l3][l4];
}


int main() {
	int T;
    f >> T;			// citesc numarul de linii
    while (T--) {
        int n;
        f >> n;			// citesc numarul de substringuri
        string s, s1;
        if (n == 1) {		// daca am un singur substring
            f >> s >> s1;
            if (s == s1) {		// verific daca e la fel cu rezultatul
                g << 1 << "\n";		// daca da 1
            } else {
                g << 0 << "\n"; 	// daca nu 0
            }
        } else {
            vec v1, v2, v3, v4, A; 		// vectori de char
            if (n == 2) {		// daca am 2 substringuri
                f >> s;		// citesc primul substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v1.push_back(s.at(i));
                f >> s;		// citesc al 2-lea substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v2.push_back(s.at(i));
                v3.clear();		// vetorul 3 si 4 sunt goi
                v4.clear();
                f >> s; 		// citesc stringul rezultat si il pun in A
                for (int i = 0; i < s.length(); i++) A.push_back(s.at(i));
                	// daca am 3 substringuri
            } else if (n == 3) {
                f >> s; 	// citesc primul substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v1.push_back(s.at(i));
                			// citesc al 2-lea substr si il pun in vector
                f >> s;
                for (int i = 0; i < s.length(); i++) v2.push_back(s.at(i));
                			// citesc al 3-lea substr si il pun in vector
                f >> s;
                for (int i = 0; i < s.length(); i++) v3.push_back(s.at(i));

                v4.clear();

                f >> s;			// citesc stringul rezultat si il pun in A
                for (int i = 0; i < s.length(); i++) A.push_back(s.at(i));
                	// daca am 4 substringuri
            } else if (n == 4) {
                f >> s;			// citesc primul substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v1.push_back(s.at(i));

                f >> s;			// citesc al 2-lea substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v2.push_back(s.at(i));

                f >> s;			// citesc al 3-lea substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v3.push_back(s.at(i));

                f >> s;			// citesc al 4-lea substr si il pun in vector
                for (int i = 0; i < s.length(); i++) v4.push_back(s.at(i));

                f >> s;			// citesc stringul rezultat si il pun in A
                for (int i = 0; i < s.length(); i++) A.push_back(s.at(i));
            }
        	// apelez functia auxiliara
            g << verificare(A, v1, v2, v3, v4) << "\n";
        }
    }
    return 0;
}
