/*
* Copyright (C) 2017, Digori Gheorghe
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;


ifstream f("points.in");		// deschid fisierul de input
ofstream g("points.out");		// deschid fisierul de output
int N, M, h, k;

struct mystruct{		// structura ce contine inceputul si sfarsitul unui interval
	int inceput;
	int sfarsit;
	mystruct(int h, int k) : inceput(h), sfarsit(k) {}


	bool operator < (const mystruct& str)const{			// comparator folosit la sortare
		return inceput < str.inceput;
	}
};


void greedy(vector<int> v, vector<mystruct> intervale, int N, int M) {
	int i;
	int min = v[0];
	int count = 0;			// numarul de solutii
	int contor = 0;			// numarul de elemente parcuurse in while
	int best_interval[] = { 0, 0}; 		// array stocarea intervalului optim
	while(contor < N) {
		for(i = 0; i < M; i++) {
			if(intervale[i].inceput <= min) {		// cautarea intervalului optim
				if(intervale[i].sfarsit > best_interval[1]) {
					best_interval[0] = intervale[i].inceput;
					best_interval[1] = intervale[i].sfarsit;
				}
			}
		}
		for(i = contor; i < N; i++) {		// cautarea punctelor acoperite
			if(v[i] <= best_interval[1]) {		// de interval
				contor++;
			}
			min  = v[contor];		// cel mai mic punct din vectorul de puncte
		}
		count++;		// counter de de intervale
	}
	g << count;		// scriere numar intervale in fisierul out
	g.close();		// inchidere fisier
}


void citire() {		// functie de citire din fisier input
	int i;
	f >> N >> M;		// citire din fisier nr puncte si intervale
	vector<int> a;
	vector<mystruct> b;		// vector de structuri
	for(i = 0; i < N; i++) {
		f >> h;
		a.push_back(h);		// stocare puncte intr-un vector
	}
	for(i = 0; i < M; i++) {
		f >> h >> k;
		b.push_back(mystruct(h, k)); 		// stocare intervale intr-un
	}		// vector de structuri
	sort(b.begin(), b.end());		// sortare intervale dupa inceput
	f.close();		// inchidere fisier de intrare
	greedy(a, b, N, M);		// apelare functie greedy
}


int main() {
	citire();		// apelare functie de citire din fisier
	return 0;
}
