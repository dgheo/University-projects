/*
* Copyright (C) 2017, Digori Gheorghe
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;
#define vec vector<long long>		// definire pentru a ma incadra in 80 caractere
#define l long long					// definire long long in l pentru reducere spatiu

ifstream f("stropitori.in");		// deschid fisierul de input
ofstream g("stropitori.out");		// deschid fisierul de output


struct mystruct{		// structura ce contine inceputul si sifarsitul unui interval
    l inceput;
	l sfarsit;
	char pozitie;
	l index_punct;
	mystruct(l h, l k)
	 : inceput(h), sfarsit(k) {}
};


// functie auxiliara ce gaseste intervalele udate
void greedy(vector<mystruct> A, l nr_stropitor, l lungime_stad) {
	int nr = 1;		// contor pentru stropitori
	long sf = A[0].sfarsit;			// initiez sf cu sfarsitul primului interval
	for(int i = 1; i < A.size(); i++) {
		if(A[i].inceput> sf) {
			nr++;			// daca sa gasit un interval ce indepineste conditiile incrementez
			sf = A[i].sfarsit;		// sf devine sfarsitul intervalului i
		}
	}
	g << nr;		// afisare in fisier output
	g.close();		// inchidere fisier de output
}

		// functie auxiliara ce gaseste intervalele posibile de udate
void filtrare(l nr_stropitor, l lungime_stad, vec &X, vec &P) {
	int i;
	vector<mystruct> A;			// vector de structuri in care pastrez intervalele
	for(i = 0; i < nr_stropitor; i++) {
		// verific intervalele posibile la dreapta si le adaug in vectorul de struct
        if ((i >= 1) && (X[i] - P[i] > X[i-1])) {
            A.push_back(mystruct((X[i] - P[i]), X[i]));
        } else if ((i == 0) && (X[i] - P[i] >= 0)) {
            A.push_back(mystruct((X[i] - P[i]), X[i]));
        }
        // verific intervalele posibile la stanga si le adaug in vect de struct
        if ((i < (nr_stropitor-1)) && ((X[i] + P[i]) < X[i+1])) {
            A.push_back(mystruct(X[i], (X[i] + P[i])));
        } else if ((i == (nr_stropitor - 1)) && (X[i] + P[i] <= lungime_stad)) {
            A.push_back(mystruct(X[i], (X[i] + P[i])));
        }
	}
	// apelez functia auxiliara ce executa un greedy simplu pe intervale
	greedy(A, nr_stropitor, lungime_stad);
}


int main() {
	string  nume_stad;
	l nr_stropitor, lungime_stad, i, h;
	vector<l> coordonata_X;
	vector<l> putere_X;
	getline(f, nume_stad);				// citesc numele stadionului
	// citesc numarul de stropitori si lungimea stad
	f >> nr_stropitor >> lungime_stad;
	for(i = 0; i < nr_stropitor; i++) {
		f >> h;							// citesc stropitorile si le pun intr-un vector
		coordonata_X.push_back(h);
	}
	for(i = 0; i < nr_stropitor; i++) {
		f >> h;							// citesc puterile stropitorilor si le pun in alt vector
		putere_X.push_back(h);
	}
	f.close();			// inchid fisierul
	// apelez functia de filtrare
	filtrare(nr_stropitor, lungime_stad, coordonata_X, putere_X);
	return 0;
}
